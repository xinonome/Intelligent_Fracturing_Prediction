import json
import os
from datetime import datetime

import numpy as np
import pandas as pd


def to_number(series):
    return pd.to_numeric(series, errors="coerce")


def is_blank(value):
    if value is None:
        return True
    if isinstance(value, float) and np.isnan(value):
        return True
    return str(value).strip() == ""


def format_time(value):
    if pd.isna(value):
        return "无时间"
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    return str(value)


def stats_for(df):
    stats = {}
    for key, label in [("SB", "砂比"), ("PL", "排量"), ("SGBY", "施工泵压")]:
        values = to_number(df[key]).dropna()
        if values.empty:
            stats[label] = {"mean": None, "var": None, "count": 0}
        else:
            stats[label] = {
                "mean": round(float(values.mean()), 4),
                "var": round(float(values.var(ddof=0)), 4),
                "count": int(values.shape[0]),
            }
    return stats


def classify_sand(sb_series):
    sb = to_number(sb_series).to_numpy()
    if sb.size == 0:
        return []
    zero_or_nan = np.isnan(sb) | (sb == 0)
    if zero_or_nan.all():
        return ["加砂前"] * sb.size
    start = 0
    while start < sb.size and zero_or_nan[start]:
        start += 1
    end = sb.size - 1
    while end >= 0 and zero_or_nan[end]:
        end -= 1
    labels = []
    for idx in range(sb.size):
        if idx < start:
            labels.append("加砂前")
        elif idx > end:
            labels.append("加砂后")
        else:
            labels.append("加砂中")
    return labels


def count_runs(series, target):
    normalized = (
        series.fillna("")
        .astype(str)
        .str.strip()
    )
    hits = normalized.eq(target)
    return int((hits & ~hits.shift(fill_value=False)).sum())


def stats_title(stats):
    lines = []
    for label, values in stats.items():
        if values["count"] == 0:
            lines.append(f"{label}: 无数据")
        else:
            lines.append(
                f"{label} 平均值={values['mean']} 方差={values['var']} (n={values['count']})"
            )
    return "<br>".join(lines)


def build_graph(df, stat_mode="full"):
    nodes = []
    edges = []

    def add_node(node_id, label, node_type, title=None, extra=None):
        payload = {"id": node_id, "label": label, "type": node_type}
        if title:
            payload["title"] = title
        if extra:
            payload.update(extra)
        nodes.append(payload)

    def add_edge(source, target, label):
        edges.append({"from": source, "to": target, "label": label})

    def add_stat_nodes(parent_id, stats, prefix):
        if stat_mode == "full":
            for metric, values in stats.items():
                mean_label = (
                    f"{metric}平均值: {values['mean']}"
                    if values["mean"] is not None
                    else f"{metric}平均值: 无数据"
                )
                var_label = (
                    f"{metric}方差: {values['var']}"
                    if values["var"] is not None
                    else f"{metric}方差: 无数据"
                )
                mean_id = f"{prefix}:{metric}:mean"
                var_id = f"{prefix}:{metric}:var"
                add_node(mean_id, mean_label, "stat")
                add_node(var_id, var_label, "stat")
                add_edge(parent_id, mean_id, "统计量")
                add_edge(parent_id, var_id, "统计量")
            return

        if stat_mode == "three":
            for metric, values in stats.items():
                if values["count"] == 0:
                    label = f"{metric}: 无数据"
                else:
                    label = f"{metric}: 平均值={values['mean']} 方差={values['var']}"
                node_id = f"{prefix}:{metric}"
                add_node(node_id, label, "stat")
                add_edge(parent_id, node_id, "统计量")
            return

        if stat_mode == "single":
            node_id = f"{prefix}:all"
            add_node(node_id, "统计量", "stat", stats_title(stats))
            add_edge(parent_id, node_id, "统计量")
            return

    for well, well_df in df.groupby("JTBH", sort=False):
        well_id = f"well:{well}"
        add_node(well_id, f"井号 {well}", "well")

        well_first_time = well_df.loc[well_df.index.min(), "SGSJ"]
        well_time_id = f"well_time:{well}"
        add_node(well_time_id, f"井号时间 {format_time(well_first_time)}", "time")
        add_edge(well_id, well_time_id, "井号时间")

        for segment, seg_df in well_df.groupby("FDBH", sort=False):
            seg_id = f"segment:{well}:{segment}"
            add_node(seg_id, f"段号 {segment}", "segment")
            add_edge(well_id, seg_id, "段号")

            seg_first_time = seg_df.loc[seg_df.index.min(), "SGSJ"]
            seg_time_id = f"segment_time:{well}:{segment}"
            add_node(seg_time_id, f"段号时间 {format_time(seg_first_time)}", "time")
            add_edge(seg_id, seg_time_id, "段号时间")

            seg_stats = stats_for(seg_df)
            add_stat_nodes(seg_id, seg_stats, f"segment_stats:{well}:{segment}")

            seg_df = seg_df.copy()
            seg_df["施工情况"] = classify_sand(seg_df["SB"])
            for condition, cond_df in seg_df.groupby("施工情况", sort=False):
                if cond_df.empty:
                    continue
                cond_id = f"condition:{well}:{segment}:{condition}"
                add_node(cond_id, f"施工情况 {condition}", "condition")
                add_edge(seg_id, cond_id, "施工情况")

                cond_first_time = cond_df.loc[cond_df.index.min(), "SGSJ"]
                cond_time_id = f"condition_time:{well}:{segment}:{condition}"
                add_node(
                    cond_time_id,
                    f"施工时间 {format_time(cond_first_time)}",
                    "time",
                )
                add_edge(cond_id, cond_time_id, "施工时间")

                cond_stats = stats_for(cond_df)
                add_stat_nodes(
                    cond_id,
                    cond_stats,
                    f"condition_stats:{well}:{segment}:{condition}",
                )

                has_working_type = cond_df["WORKING_TYPE"].notna() & (
                    cond_df["WORKING_TYPE"].astype(str).str.strip() != ""
                )
                if not has_working_type.any():
                    continue
                for working_type, wt_df in cond_df[has_working_type].groupby(
                    "WORKING_TYPE", sort=False
                ):
                    wt_id = f"worktype:{well}:{segment}:{condition}:{working_type}"
                    add_node(wt_id, f"工况 {working_type}", "worktype")
                    add_edge(cond_id, wt_id, "工况")

                    wt_first_time = wt_df.loc[wt_df.index.min(), "SGSJ"]
                    wt_time_id = (
                        f"worktype_time:{well}:{segment}:{condition}:{working_type}"
                    )
                    add_node(
                        wt_time_id,
                        f"工况时间 {format_time(wt_first_time)}",
                        "time",
                    )
                    add_edge(wt_id, wt_time_id, "工况时间")

                    wt_stats = stats_for(wt_df)
                    add_stat_nodes(
                        wt_id,
                        wt_stats,
                        f"worktype_stats:{well}:{segment}:{condition}:{working_type}",
                    )

                    suggestion_value = wt_df["SUGGESTION"].iloc[0]
                    suggestion_text = (
                        str(suggestion_value).strip()
                        if not is_blank(suggestion_value)
                        else "无建议"
                    )
                    suggestion_id = (
                        f"suggestion:{well}:{segment}:{condition}:{working_type}"
                    )
                    add_node(
                        suggestion_id,
                        f"当前建议: {suggestion_text}",
                        "suggestion",
                    )
                    add_edge(wt_id, suggestion_id, "当前建议")

    return {"nodes": nodes, "edges": edges}


def build_qa(df):
    payload = {"presets": [], "segmentStats": {}}

    def format_per_well(values):
        lines = []
        for well, value in values.items():
            lines.append(f"{well}: {value}")
        return "\n".join(lines)

    well_groups = df.groupby("JTBH", sort=False)

    # Q1: working types per well
    q1 = "每口井出现了哪些工况？"
    q1_values = {}
    for well, group in well_groups:
        items = (
            group["WORKING_TYPE"]
            .dropna()
            .astype(str)
            .str.strip()
            .loc[lambda s: s != ""]
            .unique()
            .tolist()
        )
        q1_values[well] = "、".join(items) if items else "无"
    payload["presets"].append({"question": q1, "answer": format_per_well(q1_values)})

    # Q2: count of working type "缝口暂堵"
    q2 = "每口井发生了多少次缝口暂堵？"
    q2_values = {}
    for well, group in well_groups:
        count = count_runs(group["WORKING_TYPE"], "缝口暂堵")
        q2_values[well] = int(count)
    payload["presets"].append({"question": q2, "answer": format_per_well(q2_values)})

    # Segment stats per well
    for well, group in well_groups:
        payload["segmentStats"][well] = {}
        for segment, seg_df in group.groupby("FDBH", sort=False):
            payload["segmentStats"][well][str(segment)] = stats_for(seg_df)

    # Example segment questions
    example_q1 = "段号15砂比平均值是多少？"
    example_q2 = "段号15施工泵压方差是多少？"
    payload["presets"].append(
        {"question": example_q1, "answer": "示例问题，可替换段号与指标。"}
    )
    payload["presets"].append(
        {"question": example_q2, "answer": "示例问题，可替换段号与指标。"}
    )

    return payload


def render_html(graph, qa, theme):
    template = f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>施工知识图谱与语义问答</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@300;400;600;700&display=swap" rel="stylesheet" />
  <script src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
  <style>
    :root {{
      --bg: {theme['bg']};
      --ink: {theme['ink']};
      --muted: {theme['muted']};
      --accent: {theme['accent']};
      --accent-2: {theme['accent2']};
      --card: {theme['card']};
      --stroke: {theme['stroke']};
    }}
    * {{
      box-sizing: border-box;
    }}
    body {{
      margin: 0;
      font-family: "Noto Sans SC", "PingFang SC", sans-serif;
      color: var(--ink);
      background: {theme['body_bg']};
      min-height: 100vh;
      padding: 28px;
    }}
    .app {{
      max-width: 1200px;
      margin: 0 auto;
      background: var(--card);
      border-radius: 20px;
      box-shadow: 0 18px 40px rgba(30, 27, 22, 0.12);
      border: 1px solid var(--stroke);
      overflow: hidden;
    }}
    header {{
      padding: 26px 28px 18px;
      border-bottom: 1px solid var(--stroke);
      background: {theme['header_bg']};
    }}
    header h1 {{
      margin: 0 0 8px;
      font-size: 26px;
      letter-spacing: 1px;
    }}
    header p {{
      margin: 0;
      color: var(--muted);
    }}
    .grid {{
      display: grid;
      grid-template-columns: minmax(300px, 1.2fr) minmax(260px, 0.8fr);
      gap: 22px;
      padding: 24px 28px 30px;
    }}
    #graph {{
      height: 560px;
      border: 1px solid var(--stroke);
      border-radius: 16px;
      background: {theme['graph_bg']};
      background-size: {theme['graph_bg_size']};
    }}
    .qa {{
      display: flex;
      flex-direction: column;
      gap: 18px;
    }}
    .panel {{
      background: #ffffff;
      border-radius: 16px;
      padding: 18px;
      border: 1px solid var(--stroke);
    }}
    .panel h2 {{
      margin: 0 0 10px;
      font-size: 18px;
    }}
    .preset {{
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
    }}
    .preset button {{
      border: 1px solid var(--accent);
      background: transparent;
      color: var(--accent);
      border-radius: 999px;
      padding: 6px 12px;
      cursor: pointer;
      font-size: 13px;
    }}
    .input-row {{
      display: flex;
      gap: 10px;
    }}
    .input-row input {{
      flex: 1;
      padding: 10px 12px;
      border-radius: 12px;
      border: 1px solid var(--stroke);
      font-size: 14px;
    }}
    .input-row button {{
      padding: 10px 14px;
      border-radius: 12px;
      border: none;
      background: var(--accent);
      color: #fff;
      font-weight: 600;
      cursor: pointer;
    }}
    #answer {{
      margin: 0;
      white-space: pre-line;
      color: var(--ink);
      background: rgba(210, 106, 58, 0.08);
      padding: 12px;
      border-radius: 12px;
      min-height: 88px;
      border: 1px solid rgba(210, 106, 58, 0.25);
    }}
    @media (max-width: 960px) {{
      .grid {{
        grid-template-columns: 1fr;
      }}
      #graph {{
        height: 420px;
      }}
    }}
  </style>
</head>
<body>
  <div class="app">
    <header>
      <h1>施工知识图谱与语义问答</h1>
      <p>以井号为主线，展开段号、施工情况与工况的层级关系，并提供每口井的统计问答。</p>
    </header>
    <section class="grid">
      <div id="graph"></div>
      <div class="qa">
        <div class="panel">
          <h2>语义问答</h2>
          <div class="preset" id="preset"></div>
        </div>
        <div class="panel">
          <div class="input-row">
            <input id="questionInput" placeholder="输入问题，例如：段号15砂比平均值是多少？" />
            <button id="askBtn">提问</button>
          </div>
          <p id="answer">在上方选择或输入问题。</p>
        </div>
      </div>
    </section>
  </div>

  <script>
    const KG_DATA = {json.dumps(graph, ensure_ascii=False)};
    const QA_DATA = {json.dumps(qa, ensure_ascii=False)};
    const QA_PRESETS = QA_DATA.presets || [];

    const container = document.getElementById("graph");
    const nodes = new vis.DataSet(
      KG_DATA.nodes.map((node) => {{
        const palette = {{
          well: {{ color: "{theme['node_well']}", size: 18 }},
          segment: {{ color: "{theme['node_segment']}", size: 16 }},
          condition: {{ color: "{theme['node_condition']}", size: 14 }},
          worktype: {{ color: "{theme['node_worktype']}", size: 13 }},
          time: {{ color: "{theme['node_time']}", size: 12 }},
          stat: {{ color: "{theme['node_stat']}", size: 11 }},
          suggestion: {{ color: "{theme['node_suggestion']}", size: 12 }},
        }}[node.type] || {{ color: "#666", size: 12 }};
        return {{
          ...node,
          color: palette.color,
          size: palette.size,
          shape: "dot",
          font: {{ color: "#1e1b16", size: 12 }},
        }};
      }})
    );
    const edges = new vis.DataSet(
      KG_DATA.edges.map((edge) => ({{
        from: edge.from,
        to: edge.to,
        color: {{ color: "{theme['edge']}" }},
        smooth: {{ type: "continuous" }},
        font: {{ size: 0 }},
      }}))
    );
    const network = new vis.Network(container, {{ nodes, edges }}, {{
      layout: {{
        improvedLayout: true,
      }},
      physics: {{
        enabled: true,
        barnesHut: {{
          gravitationalConstant: {theme['gravity']},
          springLength: {theme['spring']},
          springConstant: {theme['spring_k']},
          damping: {theme['damping']},
        }},
      }},
      interaction: {{ hover: true, dragNodes: true, zoomView: true }}
    }});

    const preset = document.getElementById("preset");
    QA_PRESETS.forEach((item) => {{
      const button = document.createElement("button");
      button.textContent = item.question;
      button.addEventListener("click", () => {{
        document.getElementById("questionInput").value = item.question;
        answer(item.question);
      }});
      preset.appendChild(button);
    }});

    function formatPerWell(values) {{
      return Object.entries(values)
        .map(([well, value]) => `${{well}}: ${{value}}`)
        .join("\\n");
    }}

    function answerSegmentQuestion(segmentId, metric, statType) {{
      const stats = QA_DATA.segmentStats || {{}};
      const statKey = statType === "平均值" ? "mean" : "var";
      const perWell = {{}};
      Object.entries(stats).forEach(([well, segments]) => {{
        if (!segments || !segments[segmentId]) {{
          perWell[well] = "无此段号";
          return;
        }}
        const metricStats = segments[segmentId][metric];
        if (!metricStats || metricStats[statKey] === null) {{
          perWell[well] = "无数据";
        }} else {{
          perWell[well] = metricStats[statKey];
        }}
      }});
      return formatPerWell(perWell);
    }}

    function answer(question) {{
      const normalized = (question || "").trim();
      const segmentMatch = normalized.match(
        /^段号\\s*(\\d+)\\s*(砂比|排量|施工泵压)\\s*(平均值|方差)是多少[？?]?$/
      );
      const output = document.getElementById("answer");
      if (segmentMatch) {{
        const [, segmentId, metric, statType] = segmentMatch;
        output.textContent = answerSegmentQuestion(segmentId, metric, statType);
        return;
      }}
      const match = QA_PRESETS.find((item) => item.question === normalized);
      if (match) {{
        output.textContent = match.answer;
      }} else {{
        const list = QA_PRESETS.map((item) => item.question).join("；");
        output.textContent = `我目前不支持该类查询，你可以问我：${{list}}；例如：段号15砂比平均值是多少？`;
      }}
    }}

    document.getElementById("askBtn").addEventListener("click", () => {{
      answer(document.getElementById("questionInput").value);
    }});
  </script>
</body>
</html>
"""
    return template


def main():
    excel_files = [name for name in os.listdir(".") if name.lower().endswith(".xlsx")]
    if not excel_files:
        raise FileNotFoundError("No .xlsx file found in current directory.")
    fname = excel_files[0]
    df = pd.read_excel(fname, engine="openpyxl")
    df = df[
        ["JTBH", "FDBH", "SGSJ", "SGBY", "PL", "SB", "WORKING_TYPE", "SUGGESTION"]
    ].copy()
    df["SGSJ"] = pd.to_datetime(df["SGSJ"], errors="coerce")

    theme_full = {
        "bg": "#f6f2ec",
        "ink": "#1e1b16",
        "muted": "#6b5f53",
        "accent": "#d26a3a",
        "accent2": "#245a73",
        "card": "#fffaf4",
        "stroke": "rgba(30, 27, 22, 0.15)",
        "body_bg": "radial-gradient(circle at top left, #f9f1e7, transparent 55%),"
        " radial-gradient(circle at 80% 20%, #e6f0f4, transparent 55%),"
        " var(--bg)",
        "header_bg": "linear-gradient(120deg, rgba(210, 106, 58, 0.12), rgba(36, 90, 115, 0.08))",
        "graph_bg": "radial-gradient(circle at 12px 12px, rgba(30, 27, 22, 0.08) 1px, transparent 1px)",
        "graph_bg_size": "24px 24px",
        "node_well": "#d26a3a",
        "node_segment": "#245a73",
        "node_condition": "#9c7a4a",
        "node_worktype": "#4f6c3f",
        "node_time": "#7d6b5d",
        "node_stat": "#5b4e40",
        "node_suggestion": "#c74d3c",
        "edge": "rgba(30,27,22,0.25)",
        "gravity": -3200,
        "spring": 140,
        "spring_k": 0.04,
        "damping": 0.18,
    }
    theme_three = {
        "bg": "#f2f6f4",
        "ink": "#14201a",
        "muted": "#4d5b53",
        "accent": "#2f6b4f",
        "accent2": "#6b3b2f",
        "card": "#fbfffd",
        "stroke": "rgba(20, 32, 26, 0.14)",
        "body_bg": "radial-gradient(circle at 10% 10%, #e8f3ee, transparent 55%),"
        " radial-gradient(circle at 90% 20%, #f3e9e3, transparent 55%),"
        " var(--bg)",
        "header_bg": "linear-gradient(120deg, rgba(47, 107, 79, 0.14), rgba(107, 59, 47, 0.12))",
        "graph_bg": "radial-gradient(circle at 10px 10px, rgba(20, 32, 26, 0.08) 1px, transparent 1px)",
        "graph_bg_size": "22px 22px",
        "node_well": "#2f6b4f",
        "node_segment": "#6b3b2f",
        "node_condition": "#6b6f2f",
        "node_worktype": "#2f4f6b",
        "node_time": "#5b6b62",
        "node_stat": "#354d41",
        "node_suggestion": "#a6402b",
        "edge": "rgba(20,32,26,0.22)",
        "gravity": -3000,
        "spring": 150,
        "spring_k": 0.045,
        "damping": 0.2,
    }
    theme_single = {
        "bg": "#f7f0e7",
        "ink": "#271b12",
        "muted": "#6a5a4e",
        "accent": "#a55b2a",
        "accent2": "#2a4f72",
        "card": "#fff7ee",
        "stroke": "rgba(39, 27, 18, 0.14)",
        "body_bg": "radial-gradient(circle at 18% 15%, #f7ead8, transparent 55%),"
        " radial-gradient(circle at 82% 12%, #e5eef4, transparent 55%),"
        " var(--bg)",
        "header_bg": "linear-gradient(120deg, rgba(165, 91, 42, 0.12), rgba(42, 79, 114, 0.1))",
        "graph_bg": "radial-gradient(circle at 14px 14px, rgba(39, 27, 18, 0.08) 1px, transparent 1px)",
        "graph_bg_size": "26px 26px",
        "node_well": "#a55b2a",
        "node_segment": "#2a4f72",
        "node_condition": "#8a6a47",
        "node_worktype": "#556b36",
        "node_time": "#6f5d50",
        "node_stat": "#7a2d1c",
        "node_suggestion": "#c84b3a",
        "edge": "rgba(39,27,18,0.24)",
        "gravity": -2800,
        "spring": 160,
        "spring_k": 0.05,
        "damping": 0.22,
    }

    graph = build_graph(df, stat_mode="full")
    graph_three = build_graph(df, stat_mode="three")
    graph_single = build_graph(df, stat_mode="single")
    qa = build_qa(df)

    with open("kg.json", "w", encoding="utf-8") as f:
        json.dump(graph, f, ensure_ascii=False, indent=2)

    with open("qa.json", "w", encoding="utf-8") as f:
        json.dump(qa, f, ensure_ascii=False, indent=2)

    html = render_html(graph, qa, theme_full)
    with open("index.html", "w", encoding="utf-8") as f:
        f.write(html)

    html_three = render_html(graph_three, qa, theme_three)
    with open("index_three_nodes.html", "w", encoding="utf-8") as f:
        f.write(html_three)

    html_single = render_html(graph_single, qa, theme_single)
    with open("index_single_node.html", "w", encoding="utf-8") as f:
        f.write(html_single)

    print("Generated kg.json, qa.json, index.html, index_three_nodes.html, index_single_node.html")


if __name__ == "__main__":
    main()
