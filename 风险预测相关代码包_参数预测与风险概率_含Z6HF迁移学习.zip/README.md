# 压裂参数预测与风险预警代码包

本代码包整理了当前汇报中使用的几条核心逻辑，源文件保持原样，便于后续复现和继续微调。

## 代码对应关系

1. `evaluate_same_well_unified.py`
   - 同一口井的下一时刻施工参数预测。
   - 分别预测施工泵压 `SGBY` 和排量 `PL`，模型为 LightGBM 回归器。
   - 在压力容差、排量容差同时满足时计算联合准确率（汇报中的 95.01% 对应这一类参数预测结果）。

2. `run_sand_risk_pipeline.py`
   - 基于时序窗口和专家规则标签的砂堵风险概率预测。
   - 主模型为 `KnowledgeTemporalRiskGNN`，输出 `risk_probability`。

3. `evaluate_future_risk_boundaries.py`
   - 根据风险概率校准绿/黄/红边界。
   - 绿色：低于低阈值；红色：高于高阈值；两者之间为黄色复核区。

4. `evaluate_future_risk_levels.py`
   - 预测下一采样点的绿色、黄色、红色风险状态。
   - 使用 `KnowledgeTemporalRiskGNN`，并输出混淆矩阵、分类指标和预测结果。

5. `train_future_risk_baseline.py`
   - 风险任务的传统机器学习基线，供 `run_sand_risk_pipeline.py` 调用。

6. `frac_gnn/`
   - 上述脚本依赖的数据构造、时间窗口、知识图结构和 GNN 模型模块。

## 依赖环境

安装 `requirements-future-risk.txt` 中的依赖即可。建议在 `FSL-Expert` 目录下运行脚本，并保证该目录在 Python 搜索路径中。

```powershell
pip install -r requirements-future-risk.txt
```

各脚本均需要通过命令行参数指定数据目录、增强文件和历史运行结果，具体参数可执行：

```powershell
python evaluate_same_well_unified.py --help
python run_sand_risk_pipeline.py --help
python evaluate_future_risk_boundaries.py --help
python evaluate_future_risk_levels.py --help
```

## 结果口径说明

- 参数预测准确率和风险预警准确率是两个不同任务，不能混写。
- 参数预测使用压力、排量的容差判定；风险任务使用专家复核后的风险标签及绿/黄/红分类。
- `reference_results/` 中仅放入现有运行结果的指标文件，作为本次汇报的参考，不替代重新运行。

## 新增：Z6HF → Z7HF 迁移学习

本压缩包新增了基于原 Z6HF 风险等级模型的跨井迁移流程：

- `train_future_risk_levels_transfer.py`：固定源井、加载 Z6HF 模型并迁移到目标井；
- `checkpoints/Z6HF_knowledge_risk_level_gnn.pt`：原 Z6HF 三分类风险等级模型；
- `reference_results/metrics_transfer_Z6HF_to_Z7HF.json`：Z6HF → Z7HF 实际运行结果；
- `README_Z6HF到Z7HF_迁移学习逻辑链.md`：任务定义、标签口径、GNN输入输出、数据划分、迁移步骤和评价公式。

本次 Z7HF 独立查询集三分类准确率为 **98.84%**。该数字是整体绿/黄/红分类准确率；黄红风险区 Recall 为 **88.70%**，两者应分开报告。
