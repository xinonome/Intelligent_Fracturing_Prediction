from __future__ import annotations

import numpy as np


def split_graphs_by_segment(graphs, support_ratio: float, seed: int):
    if not graphs:
        return [], []
    segment_ids = sorted({str(graph.segment_id) for graph in graphs})
    if len(segment_ids) < 2:
        raise ValueError(
            "At least two independent construction segments are required for support/query splitting"
        )
    rng = np.random.default_rng(seed)
    shuffled = rng.permutation(segment_ids)
    support_count = max(1, int(round(len(shuffled) * support_ratio)))
    support_count = min(support_count, len(shuffled) - 1)
    support_ids = set(shuffled[:support_count].tolist())
    support = [graph for graph in graphs if str(graph.segment_id) in support_ids]
    query = [graph for graph in graphs if str(graph.segment_id) not in support_ids]
    return support, query
