"""Hydraulic fracturing risk-modeling package."""


def run_experiment(*args, **kwargs):
    """Load the optional graph-training stack only when it is requested."""
    from .train import run_experiment as _run_experiment

    return _run_experiment(*args, **kwargs)


__all__ = ["run_experiment"]
